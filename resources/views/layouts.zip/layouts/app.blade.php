

@extends('layouts.versions.vertical-light') 
{{-- @extends('layouts.versions.vertical-dark')  --}}
{{-- @extends('layouts.versions.horizontal-light')  --}}
{{-- @extends('layouts.versions.horizontal-dark')  --}}
